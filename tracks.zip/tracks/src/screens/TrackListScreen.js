import React from 'react'
import {Text,StyleSheet,Button} from 'react-native';

const TrackListScreen =({navigation}) =>{
    return (
        <>
            <Text style={style.heading}>Track List Screen</Text>
            <Button 
             title="go to TrackDetail" 
             onPress={()=>navigation.navigate('TrackDetail')} />
        </>
    )
};

const style = StyleSheet.create({
    container:{
        margin:10
    },
    heading: {
        fontSize: 30,
        marginLeft: 10,
        fontWeight: "bold"
    }
})

export default TrackListScreen;