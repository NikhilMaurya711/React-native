import React, { useContext } from 'react';
import { Text, View, StyleSheet } from 'react-native';
import {Button} from 'react-native-elements';
import { Context as AuthContext } from '../context/AuthContext';
import Spacer from '../components/Spacer';

const AccountScreen = () => {
    const { signout} = useContext( AuthContext )
    return (
        <View style={style.container}>
            <Spacer>
            <Text style = {style.heading} >Account Screen</Text>
            </Spacer>
            <Spacer>
            <Button title="Sign Out" onPress={signout}  />
            </Spacer>
        </View>
    )
};

const style = StyleSheet.create({
    container:{
        margin:10
    },
    heading: {
        fontSize: 30,
        marginLeft: 10,
        fontWeight: "bold"
    }
})

export default AccountScreen;