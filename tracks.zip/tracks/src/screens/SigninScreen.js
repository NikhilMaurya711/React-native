import React, { useContext, useEffect } from 'react'
import { View, StyleSheet } from 'react-native';
import { Context as AuthContext } from "../context/AuthContext";
import AuthForm from '../components/AuthForm';
import NavLink from '../components/NavLink';
import { NavigationEvents } from 'react-navigation';

const SigninScreen = ({ navigation }) => {
    const { state, signin, clearErrorMessage  } = useContext(AuthContext);

    return (
        <View style={style.container}>
            <NavigationEvents
                onWillFocus={()=>{
                    clearErrorMessage()}}
            />
            <AuthForm
                headerText="Sign In to your Account"
                errorMessage={state.errorMessage}
                onSubmit={signin}
                submitButtonText="Signin"
            />
            <NavLink
                routeName="Signup"
                linkText="Don't have an account? sign up instead"
            />
        </View>
    )
};

const style = StyleSheet.create({

    container: {
        flex: 1,
        justifyContent: "center",
        marginBottom: 200,
        marginTop: 100
    },

})

SigninScreen.navigationOptions = () => {
    return {
        headerShown: false,
    };
};

export default SigninScreen;