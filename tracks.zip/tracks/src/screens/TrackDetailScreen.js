import React from 'react'
import { Text, View, StyleSheet } from 'react-native';

const TrackDetailScreen = () => {
    return (
        <View style={style.container}>
            <Text style={style.heading} >Track Detail Screen</Text>
        </View>
    )
};

const style = StyleSheet.create({
    container: {
        margin: 10
    },
    heading: {
        fontSize: 30,
        marginLeft: 10,
        fontWeight: "bold"
    }
})

export default TrackDetailScreen;