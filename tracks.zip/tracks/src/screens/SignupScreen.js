import React, { useContext } from 'react'
import { View, StyleSheet } from 'react-native';
import { Context as AuthContext } from "../context/AuthContext";
import AuthForm from '../components/AuthForm'
import NavLink from '../components/NavLink';
import { NavigationEvents } from 'react-navigation'

const SignupScreen = ({ navigation }) => {
    const { state, signup, clearErrorMessage } = useContext(AuthContext);

    return (
        <View style={style.container}>
            <NavigationEvents
                onWillFocus={() => {
                    clearErrorMessage()
                }}
            />
            <AuthForm
                headerText="Signup for Tracker"
                errorMessage={state.errorMessage}
                onSubmit={signup}
                submitButtonText="Signin"
            />
            <NavLink
                routeName="Signin"
                linkText="Already have an account? sign in instead"
            />
        </View>
    )
};

const style = StyleSheet.create({

    container: {
        flex: 1,
        justifyContent: "center",
        marginBottom: 200,
        marginTop: 100
    },

})

SignupScreen.navigationOptions = () => {
    return {
        headerShown: false,
    };
};

export default SignupScreen;