import { NavigationActions } from 'react-navigation';

let navigator;

export const setNavigator = (nav) => {
    navigator = nav;
};

export const navigate = (routeName,params) => {
    console.log("routename:" + routeName + " params:" + params);
    navigator.dispatch(
        NavigationActions.navigate({
            routeName,
            params
        })
    );
};