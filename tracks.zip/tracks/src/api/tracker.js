import axios from 'axios';

export default axios.create({
    baseURL:'http://af9b99666fe7.ngrok.io'
})