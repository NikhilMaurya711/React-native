import React from 'react'
import { Text, StyleSheet, TouchableOpacity } from 'react-native';
import Spacer from './Spacer';
import { withNavigation } from 'react-navigation'

const NavLink = ({ navigation, routeName, linkText }) => {
    return (
        <Spacer>
            <TouchableOpacity onPress={() => navigation.navigate(routeName)}>
                <Text style={style.sign}>{linkText}</Text>
            </TouchableOpacity>
        </Spacer>
    )
}


const style = StyleSheet.create({

    sign: {
        color: "blue",
        fontSize: 18
    }
});

export default withNavigation(NavLink);