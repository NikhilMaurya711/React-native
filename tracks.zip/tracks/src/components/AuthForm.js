import React, { useState } from 'react'
import { StyleSheet } from 'react-native';
import { Text, Button, Input } from 'react-native-elements';
import Spacer from './Spacer';

const AuthForm = ({ headerText, errorMessage, onSubmit, submitButtonText }) => {

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    return (
        <>
            <Text style={style.heading}>{headerText}</Text>
            <Spacer />
            <Input
                label="email"
                value={email}
                onChangeText={setEmail}
                autoCapitalize="none"
                autoCorrect={false}
            />
            <Spacer />
            <Input
                label="password"
                value={password}
                onChangeText={setPassword}
                autoCapitalize="none"
                autoCorrect={false}
                secureTextEntry
            />
            {errorMessage ? <Text style={style.errorMessage}>{errorMessage}</Text> : null}
            <Spacer >
                <Button 
                title={submitButtonText}
                onPress={() => onSubmit({ email, password })} />
            </Spacer>
        </>
    )

}

const style = StyleSheet.create({
    errorMessage: {
        color: "red",
        fontSize: 16,
        marginLeft: 15
    },
    heading: {
        fontSize: 24,
        marginLeft: 10,
        fontWeight: "bold"
    }
});

export default AuthForm;