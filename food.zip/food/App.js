import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import SearchScreen from './src/screen/SearchScreen';
import TestScreen from './src/screen/TestScreen';
import ResultShowScreen from './src/screen/ResultShowScreen';
 
const navigator = createStackNavigator({

    Search: SearchScreen   ,
    // Test : TestScreen ,
    ResultShow: ResultShowScreen

},{

    initialRouteName :'Search',
    defaultNavigationOptions :{
        title :'Bisiness Search'
    }
});

export default createAppContainer(navigator);
